# Unidad 12 – Gestión de Archivos en Python

## Índice

1. [¿Por qué trabajar con archivos?](#1-por-qué-trabajar-con-archivos)
2. [El sistema de archivos](#2-el-sistema-de-archivos)
3. [Rutas de archivos con `pathlib`](#3-rutas-de-archivos-con-pathlib)
4. [Crear directorios y archivos](#4-crear-directorios-y-archivos)
5. [Explorar el contenido de un directorio](#5-explorar-el-contenido-de-un-directorio)
6. [Buscar archivos con comodines (`glob`)](#6-buscar-archivos-con-comodines-glob)
7. [Mover, renombrar y eliminar archivos](#7-mover-renombrar-y-eliminar-archivos)
8. [Leer archivos de texto](#8-leer-archivos-de-texto)
9. [Escribir archivos de texto](#9-escribir-archivos-de-texto)
10. [Resumen de buenas prácticas](#10-resumen-de-buenas-prácticas)

---

## 1. ¿Por qué trabajar con archivos?

Hasta ahora, nuestros programas reciben datos del teclado y muestran resultados en pantalla. En el mundo real, eso no es suficiente:

- Los datos pueden ser **demasiados** para teclearlos a mano (listas de clientes, registros de ventas…).
- Los resultados deben **guardarse** para compartirlos o consultarlos después.
- Muchos procesos se alimentan de archivos generados por otros programas (exportaciones CSV, informes, logs…).

Python nos permite **leer, escribir y organizar archivos** de forma sencilla, lo que convierte nuestros scripts en herramientas útiles para el día a día laboral.

---

## 2. El sistema de archivos

El **sistema de archivos** es la estructura que utiliza el sistema operativo para organizar los datos almacenados en disco. Se basa en dos conceptos:

- **Archivo**: secuencia de bytes almacenada con un nombre (por ejemplo `informe.txt`).
- **Directorio (carpeta)**: contenedor que agrupa archivos y otros directorios.

La estructura es jerárquica, con un **directorio raíz** en la cima:

```
/ (Linux/macOS)  o  C:\ (Windows)
├── Usuarios/
│   └── Ana/
│       ├── Documentos/
│       │   └── informe.txt
│       └── Descargas/
└── Programas/
```

### Rutas absolutas vs. relativas

| Tipo | Descripción | Ejemplo |
|------|------------|---------|
| **Absoluta** | Empieza desde el directorio raíz | `/home/Ana/Documentos/informe.txt` |
| **Relativa** | Parte desde el directorio de trabajo actual | `Documentos/informe.txt` |

### Diferencias entre sistemas operativos

| Elemento | Windows | macOS / Linux |
|----------|---------|--------------|
| Separador de directorios | `\` (barra invertida) | `/` (barra) |
| Raíz | `C:\` | `/` |
| Carpeta de usuario | `C:\Users\Ana` | `/home/Ana` o `/Users/Ana` |

> **Importante:** Python y su módulo `pathlib` se encargan de estas diferencias por nosotros, para que nuestro código funcione en cualquier sistema operativo.

---

## 3. Rutas de archivos con `pathlib`

El módulo `pathlib` (incluido en Python desde la versión 3.4) nos permite trabajar con rutas de forma clara y portable.

### Importar y crear un objeto `Path`

```python
from pathlib import Path

# A partir de un texto
ruta = Path("Documentos/informe.txt")

# Directorio personal del usuario
home = Path.home()          # Ej: /home/Ana  o  C:\Users\Ana

# Directorio de trabajo actual
cwd = Path.cwd()            # Ej: /home/Ana/mi_proyecto
```

### Construir rutas con el operador `/`

En lugar de concatenar cadenas, usamos `/` para unir partes de una ruta de forma legible:

```python
ruta_completa = Path.home() / "Documentos" / "informe.txt"
# Resultado: /home/Ana/Documentos/informe.txt
```

### Acceder a los componentes de una ruta

```python
ruta = Path("/home/Ana/Documentos/ventas_2024.csv")

ruta.name       # "ventas_2024.csv"   → nombre completo del archivo
ruta.stem       # "ventas_2024"       → nombre sin extensión
ruta.suffix     # ".csv"              → extensión
ruta.parent     # Path("/home/Ana/Documentos")  → carpeta que lo contiene
ruta.anchor     # "/"                 → raíz del sistema
```

### Comprobar si una ruta existe

```python
ruta = Path.home() / "Documentos" / "informe.txt"

ruta.exists()    # True o False
ruta.is_file()   # True si es un archivo
ruta.is_dir()    # True si es un directorio
```

---

## 4. Crear directorios y archivos

### Crear un directorio

```python
nueva_carpeta = Path.home() / "mi_proyecto"
nueva_carpeta.mkdir(exist_ok=True)
# exist_ok=True evita un error si la carpeta ya existe
```

Para crear varias carpetas anidadas de golpe:

```python
ruta_anidada = Path.home() / "proyectos" / "python" / "datos"
ruta_anidada.mkdir(parents=True, exist_ok=True)
# parents=True crea todas las carpetas intermedias que falten
```

### Crear un archivo vacío

```python
archivo = Path.home() / "mi_proyecto" / "notas.txt"
archivo.touch()
# Crea el archivo vacío si no existe; si ya existe, no hace nada
```

> Recuerda: `.touch()` no crea las carpetas intermedias. Asegúrate de que el directorio padre exista antes de llamar a `.touch()`.

---

## 5. Explorar el contenido de un directorio

### Listar el contenido con `iterdir()`

```python
carpeta = Path.home() / "mi_proyecto"

for elemento in carpeta.iterdir():
    print(elemento.name, "→", "archivo" if elemento.is_file() else "carpeta")
```

> `.iterdir()` solo devuelve los elementos directamente dentro de la carpeta, **no** entra en subcarpetas.

---

## 6. Buscar archivos con comodines (`glob`)

El método `.glob()` permite buscar archivos usando **patrones con comodines**:

| Comodín | Significado | Ejemplo |
|---------|------------|---------|
| `*` | Cualquier número de caracteres | `*.txt` → todos los `.txt` |
| `?` | Un solo carácter | `archivo?.csv` → `archivo1.csv`, `archivoA.csv` |
| `[abc]` | Uno de los caracteres indicados | `[AB]_informe.pdf` → `A_informe.pdf`, `B_informe.pdf` |
| `**` | Búsqueda recursiva (subcarpetas) | `**/*.py` → todos los `.py` en cualquier nivel |

### Ejemplos

```python
carpeta = Path.home() / "mi_proyecto"

# Todos los archivos .txt en la carpeta
for f in carpeta.glob("*.txt"):
    print(f.name)

# Todos los archivos .csv en la carpeta y subcarpetas
for f in carpeta.rglob("*.csv"):
    print(f)
```

---

## 7. Mover, renombrar y eliminar archivos

### Mover o renombrar un archivo

```python
origen = Path("datos/antiguo.txt")
destino = Path("datos/nuevo.txt")

# Solo mover si el destino no existe (para no perder datos)
if not destino.exists():
    origen.replace(destino)
```

### Eliminar un archivo

```python
archivo = Path("datos/temporal.txt")
archivo.unlink(missing_ok=True)
# missing_ok=True evita un error si el archivo ya no existe
```

### Eliminar un directorio

```python
# Directorio vacío
carpeta_vacia = Path("datos/vacia")
carpeta_vacia.rmdir()

# Directorio con contenido → usar shutil
import shutil
shutil.rmtree(Path("datos/carpeta_con_archivos"))
```

> **¡Cuidado!** `unlink()` y `shutil.rmtree()` eliminan de forma permanente. No van a la papelera de reciclaje.

---

## 8. Leer archivos de texto

Para leer y escribir archivos usaremos la función integrada `open()` junto con la sentencia `with`, que se encarga de cerrar el archivo automáticamente al terminar.

### Leer todo el contenido de golpe: `.read()`

```python
with open("datos/mensaje.txt", mode="r", encoding="utf-8") as archivo:
    contenido = archivo.read()

print(contenido)
```

- `mode="r"` → abrir en modo lectura (*read*).
- `encoding="utf-8"` → codificación de caracteres (recomendado siempre).

### Leer línea a línea: `.readlines()` o iteración directa

```python
# Opción 1: .readlines() devuelve una lista de líneas
with open("datos/mensaje.txt", mode="r", encoding="utf-8") as archivo:
    lineas = archivo.readlines()

for linea in lineas:
    print(linea.strip())   # .strip() elimina saltos de línea sobrantes

# Opción 2: iterar directamente (más eficiente con archivos grandes)
with open("datos/mensaje.txt", mode="r", encoding="utf-8") as archivo:
    for linea in archivo:
        print(linea.strip())
```

### La sentencia `with` y por qué es importante

Cuando abrimos un archivo, el sistema operativo reserva recursos para mantener esa conexión. Si no cerramos el archivo, esos recursos quedan "ocupados" innecesariamente.

`with` garantiza que el archivo **siempre se cierre**, incluso si ocurre un error durante la ejecución:

```python
# ✅ Forma recomendada
with open("archivo.txt", "r", encoding="utf-8") as f:
    datos = f.read()
# Al salir del bloque 'with', el archivo se cierra automáticamente

# ❌ Forma no recomendada (hay que acordarse de cerrar)
f = open("archivo.txt", "r", encoding="utf-8")
datos = f.read()
f.close()   # Si se nos olvida, el archivo queda abierto
```

---

## 9. Escribir archivos de texto

### Escribir (sobrescribir): modo `"w"`

```python
with open("datos/salida.txt", mode="w", encoding="utf-8") as archivo:
    archivo.write("Primera línea del archivo\n")
    archivo.write("Segunda línea del archivo\n")
```

> **¡Atención!** El modo `"w"` **borra todo** el contenido previo del archivo. Si el archivo no existe, lo crea automáticamente.

### Añadir al final: modo `"a"` (*append*)

```python
with open("datos/salida.txt", mode="a", encoding="utf-8") as archivo:
    archivo.write("Esta línea se añade al final\n")
```

### Escribir varias líneas a la vez: `.writelines()`

```python
lineas = [
    "Manzanas: 12\n",
    "Naranjas: 8\n",
    "Plátanos: 5\n",
]

with open("datos/inventario.txt", mode="w", encoding="utf-8") as archivo:
    archivo.writelines(lineas)
```

> `.writelines()` **no** añade saltos de línea automáticamente; debemos incluir `\n` en cada cadena.

### Resumen de modos de apertura

| Modo | Descripción | ¿Crea el archivo si no existe? |
|------|------------|-------------------------------|
| `"r"` | Lectura | No (lanza error) |
| `"w"` | Escritura (sobrescribe) | Sí |
| `"a"` | Escritura (añade al final) | Sí |

---

## 10. Resumen de buenas prácticas

1. **Usa `pathlib`** para manejar rutas: tu código funcionará en Windows, macOS y Linux sin cambios.
2. **Usa `with open(...)`** siempre que leas o escribas archivos: garantiza que se cierren correctamente.
3. **Especifica `encoding="utf-8"`** para evitar problemas con caracteres especiales (ñ, acentos, emojis…).
4. **Comprueba que las rutas existen** antes de operar con ellas (`.exists()`, `.is_file()`, `.is_dir()`).
5. **Ten cuidado con el modo `"w"`**: sobrescribe el contenido sin avisar.
6. **Ten cuidado al eliminar**: `unlink()` y `shutil.rmtree()` son irreversibles.
7. **Usa `mkdir(parents=True, exist_ok=True)`** como patrón seguro para crear carpetas.
