# Unidad 12 – Ejercicios: Gestión de Archivos en Python

> **Archivo de datos necesario:** `empleados.csv` (proporcionado junto a este documento).
> Colócalo en la misma carpeta donde ejecutes los scripts.

---

## Ejercicios Básicos (1–5)

---

### Ejercicio 1 – Crear una estructura de carpetas para un proyecto

Escribe un programa que cree la siguiente estructura de carpetas dentro de una carpeta llamada `mi_proyecto/` en el directorio de trabajo actual:

```
mi_proyecto/
├── datos/
├── informes/
└── respaldos/
```

El programa debe mostrar un mensaje confirmando la creación de cada carpeta y no debe dar error si las carpetas ya existen.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path

# Definimos la carpeta base y las subcarpetas que queremos crear
carpeta_base = Path("mi_proyecto")
subcarpetas = ["datos", "informes", "respaldos"]

# Creamos cada subcarpeta
for nombre in subcarpetas:
    ruta = carpeta_base / nombre
    # parents=True crea también 'mi_proyecto/' si no existe
    # exist_ok=True evita error si la carpeta ya fue creada
    ruta.mkdir(parents=True, exist_ok=True)
    print(f"Carpeta creada: {ruta}")

print("\nEstructura del proyecto lista.")
```

</details>

---

### Ejercicio 2 – Escribir una lista de tareas en un archivo

Escribe un programa que pida al usuario que introduzca tareas por teclado, una por una, hasta que escriba `"salir"`. El programa debe guardar todas las tareas en un archivo llamado `tareas.txt`, numeradas.

Ejemplo de contenido del archivo generado:

```
1. Comprar material de oficina
2. Enviar informe al cliente
3. Revisar presupuesto mensual
```

<details>
<summary>Ver solución</summary>

```python
# Lista donde almacenamos las tareas
tareas = []

print("Introduce tus tareas (escribe 'salir' para terminar):")

while True:
    tarea = input("→ ")
    # Si el usuario escribe 'salir', dejamos de pedir tareas
    if tarea.lower() == "salir":
        break
    tareas.append(tarea)

# Escribimos las tareas en el archivo
with open("tareas.txt", mode="w", encoding="utf-8") as archivo:
    for i, tarea in enumerate(tareas, start=1):
        archivo.write(f"{i}. {tarea}\n")

print(f"\nSe han guardado {len(tareas)} tareas en 'tareas.txt'.")
```

</details>

---

### Ejercicio 3 – Leer un archivo y mostrar su contenido con información

Escribe un programa que lea el archivo `tareas.txt` (creado en el ejercicio anterior) y muestre por pantalla:

1. El número total de líneas.
2. El contenido completo del archivo.

Si el archivo no existe, el programa debe mostrar un mensaje de aviso en lugar de dar un error.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path

ruta = Path("tareas.txt")

# Comprobamos que el archivo existe antes de intentar leerlo
if not ruta.exists():
    print("El archivo 'tareas.txt' no existe. Ejecuta primero el Ejercicio 2.")
else:
    with open(ruta, mode="r", encoding="utf-8") as archivo:
        lineas = archivo.readlines()

    print(f"El archivo tiene {len(lineas)} línea(s):\n")
    for linea in lineas:
        # .strip() elimina el salto de línea del final
        print(linea.strip())
```

</details>

---

### Ejercicio 4 – Registro diario de gastos personales

Escribe un programa que permita al usuario registrar gastos. Cada gasto tiene un concepto y un importe. El programa debe **añadir** los gastos al final de un archivo llamado `gastos.txt` (sin borrar los anteriores). Cada línea del archivo tendrá el formato:

```
Concepto: Supermercado | Importe: 45.30 €
```

El programa pedirá gastos hasta que el usuario escriba `"salir"` como concepto.

<details>
<summary>Ver solución</summary>

```python
print("=== Registro de gastos ===")
print("(Escribe 'salir' como concepto para terminar)\n")

# Usamos modo "a" (append) para no borrar gastos anteriores
with open("gastos.txt", mode="a", encoding="utf-8") as archivo:
    contador = 0
    while True:
        concepto = input("Concepto: ")
        if concepto.lower() == "salir":
            break

        # Pedimos el importe y lo convertimos a número decimal
        importe = float(input("Importe (€): "))

        # Escribimos la línea en el archivo
        archivo.write(f"Concepto: {concepto} | Importe: {importe:.2f} €\n")
        contador += 1
        print("  ✓ Gasto registrado.\n")

print(f"\nSe han añadido {contador} gasto(s) a 'gastos.txt'.")
```

</details>

---

### Ejercicio 5 – Listar archivos de una carpeta por tipo

Escribe un programa que reciba por teclado la ruta a una carpeta y muestre por separado los **archivos** y los **subdirectorios** que contiene, junto con un recuento de cada tipo.

Si la ruta no existe o no es un directorio, debe mostrar un mensaje de error.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path

ruta_texto = input("Introduce la ruta de una carpeta: ")
carpeta = Path(ruta_texto)

# Validamos que la ruta existe y es un directorio
if not carpeta.exists():
    print(f"La ruta '{ruta_texto}' no existe.")
elif not carpeta.is_dir():
    print(f"La ruta '{ruta_texto}' no es un directorio.")
else:
    archivos = []
    directorios = []

    # Recorremos el contenido del directorio
    for elemento in carpeta.iterdir():
        if elemento.is_file():
            archivos.append(elemento.name)
        elif elemento.is_dir():
            directorios.append(elemento.name)

    # Mostramos resultados
    print(f"\n--- Contenido de '{carpeta}' ---")
    print(f"\nArchivos ({len(archivos)}):")
    for nombre in sorted(archivos):
        print(f"  📄 {nombre}")

    print(f"\nSubdirectorios ({len(directorios)}):")
    for nombre in sorted(directorios):
        print(f"  📁 {nombre}")
```

</details>

---

## Ejercicios de Nivel Medio (6–8)

---

### Ejercicio 6 – Buscador de archivos por extensión

Escribe un programa que pida al usuario una carpeta y una extensión de archivo (por ejemplo, `.txt`, `.csv`). El programa debe buscar **recursivamente** (en la carpeta y todas sus subcarpetas) todos los archivos con esa extensión y mostrar:

1. La ruta de cada archivo encontrado.
2. El total de archivos encontrados.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path

ruta_texto = input("Carpeta donde buscar: ")
extension = input("Extensión a buscar (ej: .txt): ").strip()

# Nos aseguramos de que la extensión empiece con punto
if not extension.startswith("."):
    extension = "." + extension

carpeta = Path(ruta_texto)

if not carpeta.is_dir():
    print(f"'{ruta_texto}' no es un directorio válido.")
else:
    # rglob busca de forma recursiva en subcarpetas
    patron = f"*{extension}"
    encontrados = list(carpeta.rglob(patron))

    if not encontrados:
        print(f"\nNo se encontraron archivos '{extension}' en '{carpeta}'.")
    else:
        print(f"\nArchivos '{extension}' encontrados:\n")
        for archivo in encontrados:
            print(f"  → {archivo}")
        print(f"\nTotal: {len(encontrados)} archivo(s).")
```

</details>

---

### Ejercicio 7 – Organizador de archivos por extensión

Escribe un programa que tome todos los archivos de una carpeta llamada `desordenado/` y los mueva a subcarpetas dentro de `organizado/`, según su extensión. Por ejemplo:

- `informe.pdf` → `organizado/pdf/informe.pdf`
- `datos.csv` → `organizado/csv/datos.csv`
- `foto.jpg` → `organizado/jpg/foto.jpg`

Antes de ejecutar el programa, crea manualmente (o con código) la carpeta `desordenado/` con algunos archivos de prueba.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path

carpeta_origen = Path("desordenado")
carpeta_destino = Path("organizado")

# Comprobamos que la carpeta de origen existe
if not carpeta_origen.is_dir():
    print("La carpeta 'desordenado/' no existe. Créala y añade archivos de prueba.")
else:
    archivos_movidos = 0

    # Recorremos solo los archivos (no subcarpetas)
    for archivo in carpeta_origen.iterdir():
        if archivo.is_file():
            # Obtenemos la extensión sin el punto (ej: "pdf", "csv")
            extension = archivo.suffix.lstrip(".").lower()

            if extension == "":
                extension = "sin_extension"

            # Creamos la subcarpeta de destino si no existe
            carpeta_ext = carpeta_destino / extension
            carpeta_ext.mkdir(parents=True, exist_ok=True)

            # Definimos la ruta de destino
            destino = carpeta_ext / archivo.name

            # Movemos solo si no existe ya en destino
            if not destino.exists():
                archivo.replace(destino)
                print(f"  Movido: {archivo.name} → {carpeta_ext}/")
                archivos_movidos += 1
            else:
                print(f"  Omitido (ya existe): {archivo.name}")

    print(f"\nProceso completado. Archivos movidos: {archivos_movidos}.")
```

</details>

---

### Ejercicio 8 – Generador de informe de texto a partir de datos

Escribe un programa que lea el archivo `empleados.csv` y genere un archivo de texto llamado `informe_departamentos.txt` con el siguiente formato:

```
=== INFORME POR DEPARTAMENTOS ===

Departamento: IT
  Número de empleados: 15
  Salario medio: 35,233.33 €

Departamento: Ventas
  Número de empleados: 14
  Salario medio: 28,750.00 €

(... etc.)
```

Para leer el CSV, utiliza el método básico de lectura de archivos (`.read()` o `.readlines()`) y procesa las líneas manualmente con `.split(",")`.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path

ruta_csv = Path("empleados.csv")

if not ruta_csv.exists():
    print("No se encuentra el archivo 'empleados.csv'.")
else:
    # Leemos el archivo CSV línea a línea
    with open(ruta_csv, mode="r", encoding="utf-8") as archivo:
        lineas = archivo.readlines()

    # La primera línea es la cabecera; la descartamos
    cabecera = lineas[0].strip().split(",")
    datos = lineas[1:]

    # Diccionario para acumular datos por departamento
    # Estructura: {departamento: [lista_de_salarios]}
    departamentos = {}

    for linea in datos:
        campos = linea.strip().split(",")
        # campos: [id, nombre, departamento, salario, ciudad, fecha_ingreso]
        departamento = campos[2]
        salario = float(campos[3])

        if departamento not in departamentos:
            departamentos[departamento] = []
        departamentos[departamento].append(salario)

    # Generamos el informe
    with open("informe_departamentos.txt", mode="w", encoding="utf-8") as informe:
        informe.write("=== INFORME POR DEPARTAMENTOS ===\n\n")

        for depto in sorted(departamentos.keys()):
            salarios = departamentos[depto]
            num_empleados = len(salarios)
            salario_medio = sum(salarios) / num_empleados

            informe.write(f"Departamento: {depto}\n")
            informe.write(f"  Número de empleados: {num_empleados}\n")
            informe.write(f"  Salario medio: {salario_medio:,.2f} €\n\n")

    print("Informe generado en 'informe_departamentos.txt'.")
```

</details>

---

## Ejercicios de Nivel Avanzado (9–10)

---

### Ejercicio 9 – Copia de seguridad selectiva de archivos

Escribe un programa que realice una copia de seguridad de una carpeta de trabajo. El programa debe:

1. Pedir al usuario la ruta de la carpeta de origen.
2. Crear una carpeta de respaldo llamada `backup_AAAA-MM-DD/` (con la fecha actual) dentro de una carpeta `respaldos/`.
3. Copiar en esa carpeta **solo** los archivos `.txt`, `.csv` y `.py` que se encuentren en la carpeta de origen (sin entrar en subcarpetas).
4. Mostrar un resumen con el número de archivos copiados de cada tipo.

**Pista:** Para copiar archivos, puedes leer el contenido del archivo de origen y escribirlo en el destino. Para obtener la fecha actual, usa el módulo `datetime` (visto en unidades anteriores).

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path
from datetime import date

# Pedimos la carpeta de origen al usuario
ruta_texto = input("Carpeta de origen para el respaldo: ")
carpeta_origen = Path(ruta_texto)

if not carpeta_origen.is_dir():
    print(f"'{ruta_texto}' no es un directorio válido.")
else:
    # Creamos la carpeta de respaldo con la fecha actual
    fecha_hoy = date.today().isoformat()  # Formato: "2025-04-05"
    carpeta_backup = Path("respaldos") / f"backup_{fecha_hoy}"
    carpeta_backup.mkdir(parents=True, exist_ok=True)

    # Extensiones que queremos respaldar
    extensiones_validas = {".txt", ".csv", ".py"}

    # Diccionario para contar archivos copiados por extensión
    contador = {ext: 0 for ext in extensiones_validas}

    for archivo in carpeta_origen.iterdir():
        # Solo procesamos archivos (no carpetas) con extensión válida
        if archivo.is_file() and archivo.suffix.lower() in extensiones_validas:
            # Leemos el contenido del archivo original
            with open(archivo, mode="r", encoding="utf-8") as f_origen:
                contenido = f_origen.read()

            # Escribimos el contenido en la carpeta de respaldo
            destino = carpeta_backup / archivo.name
            with open(destino, mode="w", encoding="utf-8") as f_destino:
                f_destino.write(contenido)

            contador[archivo.suffix.lower()] += 1

    # Mostramos el resumen
    total = sum(contador.values())
    print(f"\n=== Resumen del respaldo ({carpeta_backup}) ===\n")
    for ext, cantidad in sorted(contador.items()):
        print(f"  Archivos {ext}: {cantidad}")
    print(f"\n  Total copiados: {total}")
```

</details>

---

### Ejercicio 10 – Sistema de registro (log) de eventos para un servidor

Imagina que trabajas como administrador de sistemas y necesitas un programa que gestione archivos de log. El programa debe ofrecer un menú con las siguientes opciones:

1. **Registrar evento**: pide tipo de evento (`INFO`, `WARNING`, `ERROR`) y un mensaje. Lo añade al archivo `servidor_log.txt` con la fecha y hora actual en el formato:
   ```
   [2025-04-05 14:30:22] [WARNING] Uso de disco al 85%
   ```
2. **Consultar eventos por tipo**: pide un tipo de evento y muestra solo las líneas del log que contengan ese tipo.
3. **Estadísticas del log**: lee el archivo y muestra cuántos eventos hay de cada tipo.
4. **Archivar log**: mueve el archivo actual a una carpeta `archivo_logs/` con el nombre `log_AAAA-MM-DD.txt` y crea un nuevo `servidor_log.txt` vacío.
5. **Salir**.

Este ejercicio integra: lectura/escritura de archivos, manejo de rutas con `pathlib`, uso de `datetime`, bucles, condicionales, diccionarios, listas y funciones.

<details>
<summary>Ver solución</summary>

```python
from pathlib import Path
from datetime import datetime, date


def registrar_evento():
    """Pide datos al usuario y añade un evento al log."""
    tipos_validos = ["INFO", "WARNING", "ERROR"]
    print(f"  Tipos válidos: {', '.join(tipos_validos)}")
    tipo = input("  Tipo de evento: ").upper().strip()

    if tipo not in tipos_validos:
        print("  Tipo no válido. Operación cancelada.")
        return

    mensaje = input("  Mensaje: ")
    ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    linea = f"[{ahora}] [{tipo}] {mensaje}\n"

    # Modo "a" para añadir sin borrar lo anterior
    with open("servidor_log.txt", mode="a", encoding="utf-8") as archivo:
        archivo.write(linea)

    print("  ✓ Evento registrado correctamente.")


def consultar_por_tipo():
    """Muestra los eventos del log filtrados por tipo."""
    ruta = Path("servidor_log.txt")
    if not ruta.exists():
        print("  El archivo de log no existe todavía.")
        return

    tipo = input("  Tipo a consultar (INFO/WARNING/ERROR): ").upper().strip()

    with open(ruta, mode="r", encoding="utf-8") as archivo:
        lineas = archivo.readlines()

    # Filtramos las líneas que contienen el tipo indicado
    filtradas = [l for l in lineas if f"[{tipo}]" in l]

    if not filtradas:
        print(f"  No se encontraron eventos de tipo '{tipo}'.")
    else:
        print(f"\n  --- Eventos [{tipo}] ({len(filtradas)}) ---\n")
        for linea in filtradas:
            print(f"  {linea.strip()}")


def mostrar_estadisticas():
    """Lee el log y cuenta eventos por tipo."""
    ruta = Path("servidor_log.txt")
    if not ruta.exists():
        print("  El archivo de log no existe todavía.")
        return

    with open(ruta, mode="r", encoding="utf-8") as archivo:
        lineas = archivo.readlines()

    # Contamos ocurrencias de cada tipo
    conteo = {"INFO": 0, "WARNING": 0, "ERROR": 0}
    for linea in lineas:
        for tipo in conteo:
            if f"[{tipo}]" in linea:
                conteo[tipo] += 1
                break  # Una línea solo tiene un tipo

    total = sum(conteo.values())
    print(f"\n  === Estadísticas del log ({total} eventos) ===\n")
    for tipo, cantidad in conteo.items():
        # Calculamos el porcentaje (evitando división por cero)
        porcentaje = (cantidad / total * 100) if total > 0 else 0
        print(f"  {tipo:10s}: {cantidad:4d} ({porcentaje:.1f}%)")


def archivar_log():
    """Mueve el log actual a una carpeta de archivo y crea uno nuevo vacío."""
    ruta_log = Path("servidor_log.txt")
    if not ruta_log.exists():
        print("  No hay archivo de log que archivar.")
        return

    # Creamos la carpeta de archivo si no existe
    carpeta_archivo = Path("archivo_logs")
    carpeta_archivo.mkdir(exist_ok=True)

    # Nombre del archivo de destino con la fecha actual
    nombre_destino = f"log_{date.today().isoformat()}.txt"
    destino = carpeta_archivo / nombre_destino

    # Comprobamos que no sobreescribamos un archivo ya archivado
    if destino.exists():
        print(f"  Ya existe un archivo archivado con la fecha de hoy: {nombre_destino}")
        print("  Operación cancelada.")
        return

    # Movemos el archivo
    ruta_log.replace(destino)
    print(f"  Log archivado en: {destino}")

    # Creamos un nuevo log vacío
    ruta_log.touch()
    print("  Nuevo archivo 'servidor_log.txt' creado (vacío).")


# --- Programa principal ---

print("=" * 45)
print("  SISTEMA DE GESTIÓN DE LOG DE SERVIDOR")
print("=" * 45)

while True:
    print("\n--- Menú ---")
    print("1. Registrar evento")
    print("2. Consultar eventos por tipo")
    print("3. Estadísticas del log")
    print("4. Archivar log")
    print("5. Salir")

    opcion = input("\nElige una opción: ").strip()

    if opcion == "1":
        registrar_evento()
    elif opcion == "2":
        consultar_por_tipo()
    elif opcion == "3":
        mostrar_estadisticas()
    elif opcion == "4":
        archivar_log()
    elif opcion == "5":
        print("\n¡Hasta pronto!")
        break
    else:
        print("  Opción no válida. Inténtalo de nuevo.")
```

</details>
